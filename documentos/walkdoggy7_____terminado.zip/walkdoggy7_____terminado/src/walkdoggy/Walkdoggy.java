
package walkdoggy;

import igu.login;


public class Walkdoggy {

   
    public static void main(String[] args) {
        
        login log = new login();   //Se crea una instancia de la clase login llamada log.
        log.setVisible(true);
        log.setLocationRelativeTo(null);
    }
    
}
